import os
import boto3
import subprocess

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # S3 bucket and file details
    bucket_name = 'traffic-cam-bucket'
    ts_file_key = 'ivs/v1/251040037814/c6JrOtfTo2OT/2024/11/13/1/49/cja83ujdN2gg/media/hls/160p30/0.ts'  # Update this as needed
    mp4_file_key = 'converted_videos/0.mp4'  # New folder and file name in S3
    
    # Local paths in Lambda's /tmp directory
    ts_local_path = '/tmp/input.ts'
    mp4_local_path = '/tmp/output.mp4'
    
    # Download the .ts file from S3
    s3.download_file(bucket_name, ts_file_key, ts_local_path)
    
    # Convert .ts to .mp4 using ffmpeg
    ffmpeg_cmd = ['/var/task/ffmpeg', '-i', ts_local_path, mp4_local_path]
    result = subprocess.run(ffmpeg_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Check if ffmpeg conversion was successful
    if result.returncode != 0:
        print(f"FFmpeg error: {result.stderr.decode('utf-8')}")
        return {
            'statusCode': 500,
            'body': 'Error during video conversion'
        }
    
    # Upload the converted .mp4 file to S3
    s3.upload_file(mp4_local_path, bucket_name, mp4_file_key)
    
    # Clean up local files if needed
    os.remove(ts_local_path)
    os.remove(mp4_local_path)
    
    return {
        'statusCode': 200,
        'body': 'File converted and uploaded successfully'
    }

